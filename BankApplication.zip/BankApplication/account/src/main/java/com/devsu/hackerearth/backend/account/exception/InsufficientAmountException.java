package com.devsu.hackerearth.backend.account.exception;

public class InsufficientAmountException extends RuntimeException{
    public InsufficientAmountException(final String message){
        super(message);
    }  
}