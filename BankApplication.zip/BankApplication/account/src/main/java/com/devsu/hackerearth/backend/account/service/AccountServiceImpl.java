package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.exception.AccountNotFoundException;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {
	private final String NOT_FOUND_ACCOUNT_ID = "Cuenta no encontrada con el id [%s]";
	private final String NOT_FOUND_CLIENT_ID = "Cliente no encontrado con el id [%s]";
  private final AccountRepository accountRepository;
  private final ClientService clientService;

	public AccountServiceImpl(AccountRepository accountRepository,ClientService clientService) {
		this.accountRepository = accountRepository;
    this.clientService = clientService;
	}

    @Override
    public List<AccountDto> getAll() {
   		return accountRepository.findAll()
		                          .stream()
		                          .map(this::accountToAccountDto)
		                          .collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
   		final Account account = accountRepository.findById(id)
						.orElseThrow(()->new AccountNotFoundException(String.format(NOT_FOUND_ACCOUNT_ID, id)));
		  return accountToAccountDto(account);
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
      final ClientDto client = clientService.getClientById(accountDto.getClientId());
      if(Objects.isNull(client)){
          throw new AccountNotFoundException(String.format(NOT_FOUND_CLIENT_ID, accountDto.getClientId()));
      } 

      final Account account=accountDtoToAccount(accountDto);
      account.setId(null);
      return accountToAccountDto(accountRepository.save(account));
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        if(Objects.isNull(accountDto.getId())){
          throw new IllegalArgumentException("El id de la cuenta es obligatorio para la actualizacion");
        }
        final Account exist=accountRepository.findById(accountDto.getId())
                .orElseThrow(()->new AccountNotFoundException(String.format(NOT_FOUND_ACCOUNT_ID, accountDto.getId())));
        
        final ClientDto client = clientService.getClientById(accountDto.getClientId());
        if(Objects.isNull(client)){
            throw new AccountNotFoundException(String.format(NOT_FOUND_CLIENT_ID, accountDto.getClientId()));
        }     

		    exist.setNumber(accountDto.getNumber());
        exist.setType(accountDto.getType());
        exist.setInitialAmount(accountDto.getInitialAmount());
        exist.setActive(accountDto.isActive());
        exist.setClientId(accountDto.getClientId());

		    return accountToAccountDto(accountRepository.save(exist));
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        final Account exist=accountRepository.findById(id)
						.orElseThrow(()->new AccountNotFoundException(String.format(NOT_FOUND_ACCOUNT_ID, id)));
        exist.setActive(partialAccountDto.isActive());
        return accountToAccountDto(accountRepository.save(exist));
    }

    @Override
    public void deleteById(Long id) {
        accountRepository.findById(id)
                .orElseThrow(()->new AccountNotFoundException(String.format(NOT_FOUND_ACCOUNT_ID, id)));

        accountRepository.deleteById(id);   
    }

    private AccountDto accountToAccountDto(final Account account){
      return new AccountDto(
        account.getId(),
        account.getNumber(),
        account.getType(),
        account.getInitialAmount(),
        account.isActive(),
        account.getClientId()
      );
	  }

	  private Account accountDtoToAccount(final AccountDto accountDto){
		  final Account account = new Account();
        account.setId(accountDto.getId());
        account.setNumber(accountDto.getNumber());
        account.setType(accountDto.getType());
        account.setInitialAmount(accountDto.getInitialAmount());
        account.setActive(accountDto.isActive());
        account.setClientId(accountDto.getClientId());
        
		  return account;
	  }
    
}
