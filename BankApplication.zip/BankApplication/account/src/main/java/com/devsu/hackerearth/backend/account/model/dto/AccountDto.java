package com.devsu.hackerearth.backend.account.model.dto;

import lombok.AllArgsConstructor;
import javax.validation.constraints.*;

import lombok.Data;

@Data
@AllArgsConstructor
public class AccountDto {

	private Long id;
	@NotBlank
	private String number;
	@NotBlank
	private String type;
	private double initialAmount;
	private boolean isActive;
	private Long clientId;
}
