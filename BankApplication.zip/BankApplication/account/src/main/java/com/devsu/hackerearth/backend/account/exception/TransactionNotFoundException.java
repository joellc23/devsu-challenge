package com.devsu.hackerearth.backend.account.exception;

public class TransactionNotFoundException extends RuntimeException{
    public TransactionNotFoundException(final String message){
        super(message);
    }  
}