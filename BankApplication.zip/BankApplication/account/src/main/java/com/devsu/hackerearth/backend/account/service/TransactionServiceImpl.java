package com.devsu.hackerearth.backend.account.service;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientDto;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.exception.TransactionNotFoundException;
import com.devsu.hackerearth.backend.account.exception.InsufficientAmountException;
import com.devsu.hackerearth.backend.account.exception.AccountMissmatchException;
import com.devsu.hackerearth.backend.account.exception.AccountNotFoundException;


@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {
  private final String NOT_FOUND_ACCOUNT_ID = "Cuenta no encontrada con el id [%s]";
	private final String NOT_FOUND_TRANSACTION_ID = "Transaccion no encontrada con el id [%s]";
	private final String MISSMATCH_ACCOUNT_ID = "No se encontro ninguna cuenta para la transaccion con accont id [%s]";
  private final String NOT_FOUND_CLIENT_ID = "Cliente no encontrado con el id [%s]";
  private final String RETIRO = "Retiro";
	private final TransactionRepository transactionRepository;
	private final AccountRepository accountRepository;
  private final ClientService clientService;


	public TransactionServiceImpl(TransactionRepository transactionRepository,AccountRepository accountRepository,ClientService clientService) {
		this.transactionRepository = transactionRepository;
    this.accountRepository = accountRepository;
    this.clientService = clientService;
	}

    @Override
    public List<TransactionDto> getAll() {
    	return transactionRepository.findAll()
		.stream()
		.map(this::transactionToTransactionDto)
		.collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(final Long id) {
    		final Transaction transac = transactionRepository.findById(id)
						.orElseThrow(()->new TransactionNotFoundException(String.format(NOT_FOUND_TRANSACTION_ID, id)));
		  return transactionToTransactionDto(transac);
    }

    @Override
    public TransactionDto create(final TransactionDto transactionDto) {
    		final Account account = accountRepository.findById(transactionDto.getAccountId())
						.orElseThrow(()->new AccountNotFoundException(String.format(NOT_FOUND_ACCOUNT_ID, transactionDto.getAccountId())));
		  double balance=account.getInitialAmount();
      double transactionAmount=transactionDto.getAmount();

      if(RETIRO.equalsIgnoreCase(transactionDto.getType()) && balance < transactionAmount){
        throw new InsufficientAmountException("Saldo no disponible");
      }
      if(RETIRO.equalsIgnoreCase(transactionDto.getType())){
        balance -= transactionAmount;
      }else{
        balance += transactionAmount;
      }

      final Transaction transac = new Transaction();
      transac.setAccountId(transactionDto.getAccountId());
      transac.setDate(transactionDto.getDate());
      transac.setAmount(transactionDto.getAmount());
      transac.setType(transactionDto.getType());
      transac.setBalance(balance);

      account.setInitialAmount(balance);
      accountRepository.save(account);

      transactionRepository.save(transac);

		  return transactionToTransactionDto(transac);
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart, Date dateTransactionEnd) {
      final List<Account> accounts = accountRepository.findByClientId(clientId);
      final List<Long> accountIds = accounts.stream()
                                            .map(Account::getId)
                                            .collect(Collectors.toList());
      final List<Transaction> transactions= transactionRepository.findByAccountIdInAndDateBetween(accountIds,dateTransactionStart,dateTransactionEnd);

      final ClientDto client = clientService.getClientById(clientId);
      if(Objects.isNull(client)){
            throw new AccountNotFoundException(String.format(NOT_FOUND_CLIENT_ID, clientId));
       }    
		  return transactions.stream()
                         .map(transac->{
                            final Account account = accounts.stream()
                                                            .filter(ac->ac.getId().equals(transac.getAccountId()))
                                                            .findFirst()
                                                            .orElseThrow(()->new AccountMissmatchException(String.format(MISSMATCH_ACCOUNT_ID,transac.getAccountId())));
                            return new BankStatementDto(
                              transac.getDate(),
                              client.getName(),
                              account.getNumber(),
                              account.getType(),
                              account.getInitialAmount(),
                              account.isActive(),
                              transac.getType(),
                              transac.getAmount(),
                              transac.getBalance()
                            );                               
                         })
                         .collect(Collectors.toList());
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
		return null;
    }

    private TransactionDto transactionToTransactionDto(final Transaction transaction){
      return new TransactionDto(
        transaction.getId(),
        transaction.getDate(),
        transaction.getType(),
        transaction.getAmount(),
        transaction.getBalance(),
        transaction.getAccountId()
      );
	}
    
}
