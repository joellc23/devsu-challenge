package com.devsu.hackerearth.backend.account.exception;

public class AccountMissmatchException extends RuntimeException{
    public AccountMissmatchException(final String message){
        super(message);
    }  
}