package com.devsu.hackerearth.backend.account.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.HttpPutFormContentFilter;

@Configuration
public class RestTemplateConfig{

    @Bean
    public RestTemplate resTemplate(){
        return new RestTemplate();
    }

}