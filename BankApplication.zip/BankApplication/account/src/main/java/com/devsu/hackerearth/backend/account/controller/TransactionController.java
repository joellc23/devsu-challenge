package com.devsu.hackerearth.backend.account.controller;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.net.URI;

import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.service.TransactionService;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {
    
    private final TransactionService transactionService;

	public TransactionController(TransactionService transactionService) {
		this.transactionService = transactionService;
	}

	@RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<TransactionDto>> getAll(){
		return ResponseEntity.ok(transactionService.getAll());
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public ResponseEntity<TransactionDto> get(@PathVariable Long id){
		return ResponseEntity.ok(transactionService.getById(id));
	}

	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<TransactionDto> create(@RequestBody TransactionDto transactionDto){
		URI location=URI.create("/api/transactions");
		return ResponseEntity.created(location).body(transactionService.create(transactionDto));
	}

	@RequestMapping(value = "/clients/{clientId}/report", method = RequestMethod.GET)
    public ResponseEntity<List<BankStatementDto>> report(@PathVariable Long clientId, @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateTransactionStart, @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateTransactionEnd) {

		return ResponseEntity.ok(transactionService.getAllByAccountClientIdAndDateBetween(clientId,dateTransactionStart,dateTransactionEnd));
	}
}
