package com.devsu.hackerearth.backend.account.service;

import com.devsu.hackerearth.backend.account.model.dto.ClientDto;
import org.springframework.web.client.RestTemplate;
import org.springframework.stereotype.Service;
import org.springframework.http.ResponseEntity;


@Service
public class ClientService {

    private final RestTemplate restTemplate;

    public ClientService(RestTemplate restTemplate){
        this.restTemplate = restTemplate;
    }

    public ClientDto getClientById(final Long clientId){
        final String url= "http://localhost:8001/api/clients/"+ clientId;
        ResponseEntity<ClientDto> response = restTemplate.getForEntity(url,ClientDto.class);
        return response.getBody();
    }   
} 