package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.Optional;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;
import com.devsu.hackerearth.backend.client.exception.ClientNotFoundException;


@Service
@Transactional
public class ClientServiceImpl implements ClientService {
	private final String NOT_FOUND_CLIENT_ID = "Cliente no encontrado con el id [%s]";
	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
	public List<ClientDto> getAll() {
		return clientRepository.findAll()
		.stream()
		.map(this::clientToClientDto)
		.collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(final Long id) {
		final Client client = clientRepository.findById(id)
						.orElseThrow(()->new ClientNotFoundException(String.format(NOT_FOUND_CLIENT_ID, id)));
		return clientToClientDto(client);
	}

	@Override
	public ClientDto create(final ClientDto clientDto) {
		final Client client=clientDtoToClient(clientDto);
		client.setId(null);
		return clientToClientDto(clientRepository.save(client));
	}

	@Override
	public ClientDto update(final ClientDto clientDto) {
		if(Objects.isNull(clientDto.getId())){
			throw new IllegalArgumentException("El id del cliente es obligatorio para la actualizacion");
		}
		final Client exist=clientRepository.findById(clientDto.getId())
						.orElseThrow(()->new ClientNotFoundException(String.format(NOT_FOUND_CLIENT_ID, clientDto.getId())));
		exist.setName(clientDto.getName());
		exist.setDni(clientDto.getDni());
		exist.setPassword(clientDto.getPassword());
		exist.setGender(clientDto.getGender());
		exist.setAge(clientDto.getAge());
		exist.setAddress(clientDto.getAddress());
		exist.setPhone(clientDto.getPhone());
		exist.setActive(clientDto.isActive());

		return clientToClientDto(clientRepository.save(exist));
	}

	@Override
    public ClientDto partialUpdate(final Long id, final PartialClientDto partialClientDto) {
        final Client exist=clientRepository.findById(id)
						.orElseThrow(()->new ClientNotFoundException(String.format(NOT_FOUND_CLIENT_ID, id)));
		exist.setActive(partialClientDto.isActive());
		return clientToClientDto(clientRepository.save(exist));
    }

	@Override
	public void deleteById(Long id) {
		clientRepository.findById(id)
						.orElseThrow(()->new ClientNotFoundException(String.format(NOT_FOUND_CLIENT_ID, id)));

		clientRepository.deleteById(id);
	}

	private ClientDto clientToClientDto(final Client client){
		return new ClientDto(
			client.getId(),
			client.getDni(),
			client.getName(),
			client.getPassword(),
			client.getGender(),
			client.getAge(),
			client.getAddress(),
			client.getPhone(),
			client.isActive()
		);
	}

	private Client clientDtoToClient(final ClientDto clientDto){
		final Client client = new Client();
		client.setId(clientDto.getId());
		client.setName(clientDto.getName());
		client.setDni(clientDto.getDni());
		client.setPassword(clientDto.getPassword());
		client.setGender(clientDto.getGender());
		client.setAge(clientDto.getAge());
		client.setAddress(clientDto.getAddress());
		client.setPhone(clientDto.getPhone());
		client.setActive(clientDto.isActive());
		return client;
	}
}
