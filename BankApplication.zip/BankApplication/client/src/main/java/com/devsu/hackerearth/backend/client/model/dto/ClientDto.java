package com.devsu.hackerearth.backend.client.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import javax.validation.constraints.*;

@Data
@AllArgsConstructor
public class ClientDto {

	private Long id;
	@NotBlank
	private String dni;
	@NotBlank
	private String name;
	@NotBlank
	private String password;
	@NotBlank
	private String gender;
	@Min(0)
	private int age;
	private String address;
	private String phone;
	private boolean isActive;
}
