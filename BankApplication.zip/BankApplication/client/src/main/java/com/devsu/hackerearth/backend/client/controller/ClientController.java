package com.devsu.hackerearth.backend.client.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;

import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.service.ClientService;

@RestController
@RequestMapping("/api/clients")
public class ClientController {

	private final ClientService clientService;

	public ClientController(ClientService clientService) {
		this.clientService = clientService;
	}

	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<List<ClientDto>> getAll(){
		return ResponseEntity.ok(clientService.getAll());
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<ClientDto> get(@PathVariable Long id){

		return ResponseEntity.ok(clientService.getById(id));
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<ClientDto> create(@RequestBody ClientDto clientDto){
		URI location=URI.create("/api/clients");
		return ResponseEntity.created(location).body(clientService.create(clientDto));
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public ResponseEntity<ClientDto> update(@PathVariable Long id, @RequestBody ClientDto clientDto){
		clientDto.setId(id);
		return ResponseEntity.ok(clientService.update(clientDto));
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PATCH)
	public ResponseEntity<ClientDto> partialUpdate(@PathVariable Long id, @RequestBody PartialClientDto partialClientDto){

		return ResponseEntity.ok(clientService.partialUpdate(id, partialClientDto));
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> delete(@PathVariable Long id){
		clientService.deleteById(id);
		return ResponseEntity.noContent().build();
	}
}
