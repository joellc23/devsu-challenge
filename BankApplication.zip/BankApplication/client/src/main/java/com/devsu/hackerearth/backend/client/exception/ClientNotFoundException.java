package com.devsu.hackerearth.backend.client.exception;

public class ClientNotFoundException extends RuntimeException{
    public ClientNotFoundException(final String message){
        super(message);
    }  
}