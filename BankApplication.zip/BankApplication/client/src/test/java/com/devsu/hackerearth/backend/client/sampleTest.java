package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.HttpEntity;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.boot.web.server.LocalServerPort;


import com.devsu.hackerearth.backend.client.controller.ClientController;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.service.ClientService;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT)
public class sampleTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate resTemplate;

    @Autowired
    private ClientRepository clientRepository;

	private ClientService clientService = mock(ClientService.class);
	private ClientController clientController = new ClientController(clientService);

    @Test
    public void integrationTestCreate(){
        final String baseUrl = "http://localhost:"+port+"/api/clients";

        final ClientDto client = new ClientDto(
            null,
            "12345566",
            "Joel Leottau",
            "pass1234",
            "Masculino",
            33,
            "direccion",
            "66324937",
            true
        );

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<ClientDto> request = new HttpEntity<>(client,headers);
        ResponseEntity<ClientDto> response = resTemplate.postForEntity(baseUrl,request,ClientDto.class);
        
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertNotNull(response.getBody().getId());
        assertEquals("Joel Leottau", response.getBody().getName());
        assertEquals("12345566", response.getBody().getDni());
        assertEquals("Masculino", response.getBody().getGender());
        assertEquals(33, response.getBody().getAge());
        assertEquals("direccion", response.getBody().getAddress());
        assertEquals("66324937", response.getBody().getPhone());
        assertEquals("pass1234", response.getBody().getPassword());
        assertTrue(response.getBody().isActive());   
    }

    @Test
    void createClientTest() {
        // Arrange
        ClientDto newClient = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999", true);
        ClientDto createdClient = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999", true);
        when(clientService.create(newClient)).thenReturn(createdClient);

        // Act
        ResponseEntity<ClientDto> response = clientController.create(newClient);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(createdClient, response.getBody());
    }

    @Test
    void testClient(){
        Client client = new Client();
        client.setId(1l);
        client.setName("Joel Leottao");
        client.setDni("1234567");
        client.setGender("Masculino");
        client.setAge(34);
        client.setAddress("Guayabal calle 47 b # 12 sur-12");
        client.setPhone("315 321 8943");
        client.setPassword("1234567");
        client.setActive(true);

        assertEquals(1l, client.getId());
        assertEquals("Joel Leottao", client.getName());
        assertEquals("1234567", client.getDni());
        assertEquals("Masculino", client.getGender());
        assertEquals(34, client.getAge());
        assertEquals("Guayabal calle 47 b # 12 sur-12", client.getAddress());
        assertEquals("315 321 8943", client.getPhone());
        assertEquals("1234567", client.getPassword());
        assertTrue(client.isActive());   
    }
}
